import imgOne from "../assets/FemaleAvatar.png";



export const teacherObject = [
    {
        image: imgOne,
        Name: "Miss Firdos Mansuri",
    },
    {
        image: imgOne,
        Name: "Mrs Rishicha Rathore",
    },
    {
        image: imgOne,
        Name: "Miss Tasneem Hussain",
    },
    {
        image: imgOne,
        Name: "Miss Ruchi Sharma",
    }
];




