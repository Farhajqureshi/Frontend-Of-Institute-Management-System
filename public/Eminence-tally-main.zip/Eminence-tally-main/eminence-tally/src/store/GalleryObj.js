export const gallaryObject = [

    {
        imgOne:"https://workik-widget-assets.s3.amazonaws.com/widget-assets/images/PP5.4.svg",
        imgTwo:"https://workik-widget-assets.s3.amazonaws.com/widget-assets/images/PP5.5.svg",
        imgThree:"https://workik-widget-assets.s3.amazonaws.com/widget-assets/images/PP5.6.svg",
        classOne: "imgs"
    },

    {
        imgOne:"https://workik-widget-assets.s3.amazonaws.com/widget-assets/images/PP5.4.svg",
        imgTwo:"https://workik-widget-assets.s3.amazonaws.com/widget-assets/images/PP5.5.svg",
        imgThree:"https://workik-widget-assets.s3.amazonaws.com/widget-assets/images/PP5.6.svg",
    },

    {
        imgOne:"https://workik-widget-assets.s3.amazonaws.com/widget-assets/images/PP5.4.svg",
        imgTwo:"https://workik-widget-assets.s3.amazonaws.com/widget-assets/images/PP5.5.svg",
        imgThree:"https://workik-widget-assets.s3.amazonaws.com/widget-assets/images/PP5.6.svg",
    }
]